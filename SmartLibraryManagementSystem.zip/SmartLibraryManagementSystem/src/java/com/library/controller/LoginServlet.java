package com.library.controller;

import com.library.dao.StudentDAO;
import com.library.dao.UserDAO;
import com.library.model.Student;
import com.library.model.User;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();
    private final StudentDAO studentDAO = new StudentDAO();

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        try {
            User user = userDAO.authenticate(username, password);

            if (user != null && "ADMIN".equalsIgnoreCase(user.getRole())) {
                HttpSession old = req.getSession(false);
                if (old != null) old.invalidate();

                HttpSession session = req.getSession(true);
                session.setAttribute("user", user);
                session.setMaxInactiveInterval(30 * 60);
                resp.sendRedirect(req.getContextPath() + "/admin/dashboard.jsp");

            } else if (user != null && "USER".equalsIgnoreCase(user.getRole())) {
                // Demo USER account is connected to Student ID 1.
                Student student = studentDAO.findById(1);
                if (student != null) {
                    HttpSession old = req.getSession(false);
                    if (old != null) old.invalidate();

                    HttpSession session = req.getSession(true);
                    session.setAttribute("student", student);
                    session.setAttribute("studentId", student.getId());
                    session.setMaxInactiveInterval(30 * 60);
                    resp.sendRedirect(req.getContextPath() + "/student/dashboard.jsp");
                } else {
                    resp.sendRedirect(req.getContextPath() + "/login.jsp?error=1");
                }
            } else {
                resp.sendRedirect(req.getContextPath() + "/login.jsp?error=1");
            }
        } catch (Exception e) {
            throw new ServletException("Login failed", e);
        }
    }
}
