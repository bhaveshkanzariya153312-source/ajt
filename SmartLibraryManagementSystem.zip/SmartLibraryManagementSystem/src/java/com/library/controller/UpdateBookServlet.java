package com.library.controller;

import com.library.dao.BookDAO;
import com.library.model.Book;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/updateBook")
public class UpdateBookServlet extends HttpServlet {
    private final BookDAO dao = new BookDAO();

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            Book b = new Book();
            b.setId(Integer.parseInt(req.getParameter("id")));
            b.setTitle(req.getParameter("title").trim());
            b.setAuthor(req.getParameter("author").trim());
            b.setCategory(req.getParameter("category"));
            b.setIsbn(req.getParameter("isbn"));
            b.setQuantity(Integer.parseInt(req.getParameter("quantity")));
            if (b.getQuantity() < 1) throw new IllegalArgumentException("Quantity must be at least 1.");
            if (!dao.update(b)) {
                resp.sendRedirect(req.getContextPath() + "/admin/edit-book.jsp?id=" + b.getId() + "&error=1");
                return;
            }
            resp.sendRedirect(req.getContextPath() + "/admin/books.jsp?msg=updated");
        } catch (Exception e) {
            throw new ServletException("Unable to update book", e);
        }
    }
}
