package com.library.controller;

import com.library.dao.StudentDAO;
import com.library.model.Student;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/studentLogin")
public class StudentLoginServlet extends HttpServlet {
    private final StudentDAO dao = new StudentDAO();

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            Student student = dao.authenticate(id, req.getParameter("password"));
            if (student != null) {
                HttpSession old = req.getSession(false);
                if (old != null) old.invalidate();
                HttpSession session = req.getSession(true);
                session.setAttribute("student", student);
                session.setAttribute("studentId", student.getId());
                session.setMaxInactiveInterval(30 * 60);
                resp.sendRedirect(req.getContextPath() + "/student/dashboard.jsp");
            } else {
                resp.sendRedirect(req.getContextPath() + "/student-login.jsp?error=1");
            }
        } catch (NumberFormatException e) {
            resp.sendRedirect(req.getContextPath() + "/student-login.jsp?error=1");
        } catch (Exception e) {
            throw new ServletException("Student login failed", e);
        }
    }
}
