package com.library.controller;

import com.library.dao.BookDAO;
import com.library.model.Book;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/addBook")
public class AddBookServlet extends HttpServlet {
    private final BookDAO dao = new BookDAO();

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            Book b = new Book();
            b.setTitle(req.getParameter("title").trim());
            b.setAuthor(req.getParameter("author").trim());
            b.setCategory(req.getParameter("category"));
            b.setIsbn(req.getParameter("isbn"));
            b.setQuantity(Integer.parseInt(req.getParameter("quantity")));
            if (b.getQuantity() < 1) throw new IllegalArgumentException("Quantity must be at least 1.");
            dao.add(b);
            resp.sendRedirect(req.getContextPath() + "/admin/books.jsp?msg=added");
        } catch (Exception e) {
            throw new ServletException("Unable to add book", e);
        }
    }
}
