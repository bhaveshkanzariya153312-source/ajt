package com.library.controller;

import com.library.dao.StudentDAO;
import com.library.model.Student;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/addStudent")
public class AddStudentServlet extends HttpServlet {
    private final StudentDAO dao = new StudentDAO();

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            Student s = new Student();
            s.setName(req.getParameter("name").trim());
            s.setEmail(req.getParameter("email"));
            s.setPhone(req.getParameter("phone"));
            s.setCourse(req.getParameter("course"));
            dao.add(s);
            resp.sendRedirect(req.getContextPath() + "/admin/students.jsp?msg=added");
        } catch (Exception e) {
            throw new ServletException("Unable to add student", e);
        }
    }
}
