SMART LIBRARY MANAGEMENT SYSTEM - AJT PROJECT
================================================

TECHNOLOGY
----------
JSP + Java Servlets + JDBC + MySQL + HTML + CSS + Bootstrap + JavaScript
Server: Apache Tomcat 9
Architecture: MVC-style (View / Controller / DAO / Model)

FEATURES
--------
1. Admin Login / Logout
2. Secure session management
3. Admin Dashboard with live statistics
4. Book Add / Update / Delete / Search
5. Book availability tracking
6. Student Add / Update / Delete / List
7. Student Login / Logout
8. Student Dashboard
9. Student book search
10. Student borrowing history
11. Issue Book with transaction-safe JDBC
12. Return Book with transaction-safe JDBC
13. Automatic overdue fine at Rs. 5/day
14. Fine management
15. Overdue statistics
16. CSV report export
17. PDF issue receipt
18. PDF return receipt
19. Responsive UI
20. MySQL foreign keys and indexes

REQUIREMENTS
------------
JDK 8 or newer
Apache NetBeans
Apache Tomcat 9
MySQL 8.x
Maven (NetBeans can use its bundled Maven)

DATABASE SETUP
--------------
1. Start MySQL.
2. Open database.sql in MySQL Workbench.
3. Execute the complete script.
4. Default database: smart_library
5. Default MySQL user: root
6. Default MySQL password: root
7. If your password is different, edit:
   src/java/com/library/dao/DatabaseConnection.java

ADMIN LOGIN
-----------
Username: admin
Password: admin123

USER LOGIN
----------
Username: user
Password: user123
The demo USER account opens Student ID 1's student dashboard.

STUDENT LOGIN
-------------
Student ID: 1
Password: user123

RUN IN NETBEANS
---------------
1. Extract the ZIP.
2. Open the project folder containing pom.xml.
3. In NetBeans: File -> Open Project.
4. Configure Apache Tomcat 9.
5. Right-click project -> Clean and Build.
6. Right-click project -> Run.
7. Open:
   http://localhost:8080/SmartLibraryManagementSystem/

IMPORTANT
---------
This project uses javax.servlet.* and is configured for Tomcat 9.
Do NOT use Tomcat 10/10.1 with this version unless you migrate javax -> jakarta.

DEMO FLOW FOR COLLEGE
---------------------
Home -> Admin Login -> Dashboard
-> Add Book -> Manage Books -> Add Student
-> Issue Book -> PDF Issue Receipt
-> Return Book -> PDF Return Receipt
-> Fines -> Reports -> Export CSV
Then:
Home -> Student Login -> Dashboard
-> Search Books -> My Books -> My Fine -> Profile -> Logout

PDF RECEIPTS
------------
Issue and return operations automatically generate a PDF receipt.
No extra PDF library is required.

NOTE
----
For a real production system, use stronger password hashing, CSRF protection,
connection pooling, server-side validation and HTTPS. This project is designed
as a college-level Advanced Java Technology demonstration.
