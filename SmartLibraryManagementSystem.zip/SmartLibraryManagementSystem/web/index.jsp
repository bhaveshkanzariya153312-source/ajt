<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Smart Library Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="landing">
<div class="hero">
    <div class="hero-card">
        <div class="logo-circle">📚</div>
        <h1>Smart Library Management System</h1>
        <p>Advanced Java Technology (AJT) based library portal</p>
        <div class="hero-buttons">
            <a class="btn" href="login.jsp">🔐 Admin Login</a>
            <a class="btn secondary" href="student-login.jsp">🎓 Student Portal</a>
        </div>
        <div class="tech-line">JSP • Servlet • JDBC • MySQL • Apache Tomcat</div>
    </div>
</div>
</body>
</html>
