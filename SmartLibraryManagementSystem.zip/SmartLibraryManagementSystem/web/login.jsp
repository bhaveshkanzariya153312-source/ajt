<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="landing">
<div class="hero">
    <div class="login-card">
        <div class="logo-circle">🔐</div>
        <h2>Admin Login</h2>
        <p>Sign in to manage the library.</p>
        <% if ("1".equals(request.getParameter("error"))) { %>
            <div class="alert error">Invalid username or password.</div>
        <% } %>
        <form method="post" action="login">
            <label>Username</label>
            <input type="text" name="username" required autocomplete="username">
            <label>Password</label>
            <input type="password" name="password" required autocomplete="current-password">
            <button class="btn full" type="submit">Login</button>
        </form>
        <p class="hint">Admin: <strong>admin</strong> / <strong>admin123</strong><br>User: <strong>user</strong> / <strong>user123</strong></p>
        <a href="index.jsp">← Back to Home</a>
    </div>
</div>
</body>
</html>
