<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html><head><title>Student Portal</title><link rel="stylesheet" href="assets/css/style.css"><meta name="viewport" content="width=device-width,initial-scale=1"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="landing"><div class="hero"><div class="login-card">
<div class="logo-circle">🎓</div><h2>Student Portal</h2><p>Secure student login</p>
<% if ("1".equals(request.getParameter("error"))) { %><div class="alert error">Invalid Student ID or password.</div><% } %>
<form method="post" action="studentLogin">
<label>Student ID</label><input type="number" name="id" min="1" required placeholder="e.g. 1">
<label>Password</label><input type="password" name="password" required placeholder="Enter password">
<button class="btn full" type="submit">Login to Portal</button>
</form>
<p class="hint">Demo: Student ID <strong>1</strong> / Password <strong>user123</strong></p>
<a href="index.jsp">← Back to Home</a>
</div></div></body></html>
