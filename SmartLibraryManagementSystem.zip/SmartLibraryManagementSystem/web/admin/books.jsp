<%@ page import="com.library.model.User" %>
<%
if (session.getAttribute("user") == null) { response.sendRedirect(request.getContextPath() + "/login.jsp"); return; }
%>

<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.library.dao.BookDAO,com.library.model.Book,java.util.List" %>
<%
String q=request.getParameter("q");
List<Book> books=new BookDAO().getAll(q);
String msg=request.getParameter("msg");
%>
<!DOCTYPE html><html><head><title>Books</title><link rel="stylesheet" href="<%=request.getContextPath()%>/assets/css/style.css"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body><div class="app-shell"><jsp:include page="/includes/sidebar.jsp"/><main class="main-content"><jsp:include page="/includes/navbar.jsp"/>
<section class="page">
<div class="page-heading"><div><h1>Book Management</h1><p>Add, search, edit and remove books.</p></div><a class="btn" href="add-book.jsp">+ Add Book</a></div>
<% if("added".equals(msg)){ %><div class="alert success">Book added successfully.</div><% } else if("updated".equals(msg)){ %><div class="alert success">Book updated successfully.</div><% } else if("deleted".equals(msg)){ %><div class="alert success">Book deleted successfully.</div><% } else if("cannotDelete".equals(msg)){ %><div class="alert error">Book cannot be deleted while it is issued.</div><% } %>
<form class="search-bar" method="get" action="books.jsp"><input name="q" value="<%=q==null?"":q%>" placeholder="Search title, author, category or ISBN"><button class="btn" type="submit">Search</button></form>
<div class="card table-card"><div class="table-wrap"><table><thead><tr><th>ID</th><th>Title</th><th>Author</th><th>Category</th><th>ISBN</th><th>Qty</th><th>Available</th><th>Action</th></tr></thead><tbody>
<% if(books.isEmpty()){ %><tr><td colspan="8" class="empty">No books found.</td></tr><% } else { for(Book b:books){ %>
<tr><td><%=b.getId()%></td><td><strong><%=b.getTitle()%></strong></td><td><%=b.getAuthor()%></td><td><%=b.getCategory()==null?"":b.getCategory()%></td><td><%=b.getIsbn()==null?"":b.getIsbn()%></td><td><%=b.getQuantity()%></td><td><span class="badge <%=b.getAvailable()>0?"available":"unavailable"%>"><%=b.getAvailable()%></span></td><td><a href="edit-book.jsp?id=<%=b.getId()%>">Edit</a> | <a class="danger-link" href="<%=request.getContextPath()%>/deleteBook?id=<%=b.getId()%>" onclick="return confirm('Delete this book?')">Delete</a></td></tr>
<% }} %></tbody></table></div></div>
</section><jsp:include page="/includes/footer.jsp"/></main></div></body></html>
