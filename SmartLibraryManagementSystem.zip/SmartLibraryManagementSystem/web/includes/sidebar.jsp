<%
String ctx = request.getContextPath();
%>
<aside class="sidebar">
    <div class="side-title">📚 Smart Library</div>
    <a href="<%=ctx%>/admin/dashboard.jsp">🏠 Dashboard</a>
    <a href="<%=ctx%>/admin/books.jsp">📖 Books</a>
    <a href="<%=ctx%>/admin/add-book.jsp">➕ Add Book</a>
    <a href="<%=ctx%>/admin/students.jsp">🎓 Students</a>
    <a href="<%=ctx%>/admin/add-student.jsp">👤 Add Student</a>
    <a href="<%=ctx%>/admin/issue-book.jsp">📤 Issue Book</a>
    <a href="<%=ctx%>/admin/return-book.jsp">📥 Return Book</a>
    <a href="<%=ctx%>/admin/fines.jsp">💰 Fines</a>
    <a href="<%=ctx%>/admin/reports.jsp">📊 Reports</a>
    <a href="<%=ctx%>/logout">🚪 Logout</a>
</aside>
