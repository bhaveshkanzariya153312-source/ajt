<%
String ctx = request.getContextPath();
%>
<header class="topbar">
    <div class="brand">📚 SmartLib</div>
    <div class="top-actions">
        <span class="user-badge">Admin Panel</span>
        <a class="logout-link" href="<%=ctx%>/logout">Logout</a>
    </div>
</header>
