<footer class="footer">
    <p>Smart Library Management System • AJT Project • JSP + Servlet + JDBC + MySQL</p>
</footer>
