<%
com.library.model.Student loggedStudent = (com.library.model.Student)session.getAttribute("student");
if (loggedStudent == null) { response.sendRedirect(request.getContextPath() + "/student-login.jsp"); return; }
int id = loggedStudent.getId();
%>

<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.library.dao.BookDAO,com.library.model.Book,java.util.List" %>
<%
List<Book> books=new BookDAO().getAll(request.getParameter("q"));
%>
<!DOCTYPE html><html><head><title>Library Books</title><link rel="stylesheet" href="<%=request.getContextPath()%>/assets/css/style.css"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body><div class="student-shell"><aside class="sidebar student-side"><div class="side-title">🎓 Student Portal</div><a href="dashboard.jsp">🏠 Dashboard</a><a href="books.jsp">📖 Books</a><a href="my-books.jsp">📚 My Books</a><a href="my-fine.jsp">💰 My Fine</a><a href="profile.jsp">👤 Profile</a><a href="<%=request.getContextPath()%>/studentLogout">🚪 Logout</a></aside>
<main class="main-content"><header class="topbar"><div class="brand">Available Books</div><div class="user-badge"><%=loggedStudent.getName()%></div></header><section class="page">
<div class="page-heading"><div><h1>Library Books</h1><p>Search by title, author, category or ISBN.</p></div></div>
<form class="search-bar" method="get"><input name="q" value="<%=request.getParameter("q")==null?"":request.getParameter("q")%>" placeholder="Search title, author, category or ISBN"><button class="btn">🔎 Search</button></form>
<div class="card table-card"><div class="table-wrap"><table><thead><tr><th>Title</th><th>Author</th><th>Category</th><th>ISBN</th><th>Availability</th></tr></thead><tbody>
<% for(Book b:books){ %><tr><td><strong><%=b.getTitle()%></strong></td><td><%=b.getAuthor()%></td><td><%=b.getCategory()==null?"":b.getCategory()%></td><td><%=b.getIsbn()==null?"":b.getIsbn()%></td><td><span class="badge <%=b.getAvailable()>0?"available":"unavailable"%>"><%=b.getAvailable()%> available</span></td></tr><% } %>
<% if(books.isEmpty()){ %><tr><td colspan="5" class="empty">No books found.</td></tr><% } %></tbody></table></div></div>
</section><jsp:include page="/includes/footer.jsp"/></main></div></body></html>
