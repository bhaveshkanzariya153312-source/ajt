<%
com.library.model.Student loggedStudent = (com.library.model.Student)session.getAttribute("student");
if (loggedStudent == null) { response.sendRedirect(request.getContextPath() + "/student-login.jsp"); return; }
int id = loggedStudent.getId();
%>

<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.library.dao.IssueDAO,com.library.dao.FineDAO,com.library.model.Issue,java.util.List" %>
<%
List<Issue> issues=new IssueDAO().getAllForStudent(id);
double fine=new FineDAO().getStudentFine(id);
int current=0; for(Issue i:issues) if("ISSUED".equals(i.getStatus())) current++;
%>
<!DOCTYPE html><html><head><title>Student Dashboard</title><link rel="stylesheet" href="<%=request.getContextPath()%>/assets/css/style.css"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body><div class="student-shell"><aside class="sidebar student-side">
<div class="side-title">🎓 Student Portal</div>
<a href="dashboard.jsp">🏠 Dashboard</a><a href="books.jsp">📖 Books</a><a href="my-books.jsp">📚 My Books</a><a href="my-fine.jsp">💰 My Fine</a><a href="profile.jsp">👤 Profile</a><a href="<%=request.getContextPath()%>/studentLogout">🚪 Logout</a>
</aside><main class="main-content"><header class="topbar"><div class="brand">Smart Library • Student</div><div class="user-badge"><%=loggedStudent.getName()%></div></header>
<section class="page"><div class="page-heading"><div><h1>Welcome, <%=loggedStudent.getName()%> 👋</h1><p>Your library account overview.</p></div></div>
<div class="stats"><div class="stat-card"><span>📚 Current Issues</span><strong><%=current%></strong></div><div class="stat-card"><span>📜 Total History</span><strong><%=issues.size()%></strong></div><div class="stat-card"><span>💰 Current Fine</span><strong>₹<%=String.format("%.0f",fine)%></strong></div><div class="stat-card"><span>🎓 Course</span><strong class="small-stat"><%=loggedStudent.getCourse()==null?"":loggedStudent.getCourse()%></strong></div></div>
<div class="card"><h2>Student Services</h2><div class="quick-links"><a class="quick" href="books.jsp">🔎 Search Books</a><a class="quick" href="my-books.jsp">📚 My Books</a><a class="quick" href="my-fine.jsp">💰 Check Fine</a><a class="quick" href="profile.jsp">👤 My Profile</a></div></div>
</section><jsp:include page="/includes/footer.jsp"/></main></div></body></html>
