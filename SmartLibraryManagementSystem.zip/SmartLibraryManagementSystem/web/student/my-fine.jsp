<%
com.library.model.Student loggedStudent = (com.library.model.Student)session.getAttribute("student");
if (loggedStudent == null) { response.sendRedirect(request.getContextPath() + "/student-login.jsp"); return; }
int id = loggedStudent.getId();
%>

<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.library.dao.FineDAO,com.library.model.Fine,java.util.List" %>
<%
FineDAO fdao=new FineDAO(); double total=fdao.getStudentFine(id); List<Fine> fines=fdao.getAllActiveFines();
%>
<!DOCTYPE html><html><head><title>My Fine</title><link rel="stylesheet" href="<%=request.getContextPath()%>/assets/css/style.css"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body><div class="student-shell"><aside class="sidebar student-side"><div class="side-title">🎓 Student Portal</div><a href="dashboard.jsp">🏠 Dashboard</a><a href="books.jsp">📖 Books</a><a href="my-books.jsp">📚 My Books</a><a href="my-fine.jsp">💰 My Fine</a><a href="profile.jsp">👤 Profile</a><a href="<%=request.getContextPath()%>/studentLogout">🚪 Logout</a></aside>
<main class="main-content"><header class="topbar"><div class="brand">My Fine</div><div class="user-badge"><%=loggedStudent.getName()%></div></header><section class="page">
<div class="page-heading"><div><h1>My Fine</h1><p>Automatic calculation at ₹5 per overdue day.</p></div></div>
<div class="student-fine-box"><span>Current Fine</span><strong>₹<%=String.format("%.0f",total)%></strong><small>Only active overdue transactions are included.</small></div>
<div class="card table-card"><div class="table-wrap"><table><thead><tr><th>Book</th><th>Due Date</th><th>Days Late</th><th>Fine</th></tr></thead><tbody>
<% boolean found=false; for(Fine f:fines){ if(f.getStudentId()==id && f.getDays()>0){found=true;%><tr><td><%=f.getBookTitle()%></td><td><%=f.getDueDate()%></td><td><%=f.getDays()%></td><td>₹<%=String.format("%.0f",f.getAmount())%></td></tr><% }} if(!found){ %><tr><td colspan="4" class="empty">No overdue fine. Great!</td></tr><% } %>
</tbody></table></div></div></section><jsp:include page="/includes/footer.jsp"/></main></div></body></html>
